# 1.0.0-alpha.1 (2023-02-11)


### Features

* events base ([fcabf1a](https://github.com/parvum-lambda/events/commit/fcabf1a0e395f4deb2e936bb37fe1fd57165c336))

# 1.0.0-alpha.1 (2023-02-11)


### Features

* events base ([fcabf1a](https://github.com/parvum-lambda/events/commit/fcabf1a0e395f4deb2e936bb37fe1fd57165c336))
